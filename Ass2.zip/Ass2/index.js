const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const productController = require('./productController');



// Middleware
app.use(express.json());
app.use(cors());

// Connect to MongoDB 
mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.2', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Define a route to display the welcome message
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to dressStore application' });
});

// Start the Express server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Create a new product
app.post('/products', productController.createProduct);

// Get a list of all products
app.get('/products', productController.getProducts);

app.put('/products/:id', productController.updateProduct);

app.delete('/products/:id', productController.deleteProduct);





